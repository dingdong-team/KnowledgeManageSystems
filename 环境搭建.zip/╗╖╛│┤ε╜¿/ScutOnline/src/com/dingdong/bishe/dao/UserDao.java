package com.dingdong.bishe.dao;

public interface UserDao {
	public boolean validate(String username, String password);
}
