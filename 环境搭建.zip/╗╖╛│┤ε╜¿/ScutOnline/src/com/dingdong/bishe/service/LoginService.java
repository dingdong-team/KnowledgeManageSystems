package com.dingdong.bishe.service;

public interface LoginService {
	public boolean validate(String username,String password);
}
